create view claim_v(id, original_text, response_id) as
SELECT row_number() OVER (ORDER BY responses.updated_at) AS id,
       responses.original_text,
       responses.id                                      AS response_id
FROM responses
WHERE responses.resp_category = 'claim'::category;

alter table claim_v
    owner to root;

